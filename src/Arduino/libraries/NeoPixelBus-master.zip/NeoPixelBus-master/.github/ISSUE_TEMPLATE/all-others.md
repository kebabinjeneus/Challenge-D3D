---
name: All others
about: If your issue doesn't fit the other two, this will guide you to support.
title: "[DELETE ME]"
labels: NOT AN ISSUE
assignees: ''

---

### STOP
If you are seeking support, then please use the gitter channel by following this link.
[NeoPixelBus Gitter Channel](https://gitter.im/Makuna/NeoPixelBus)

If you submit issues that are not traceable bugs or feature requests, it will get closed and you will be directed to the gitter channel.
